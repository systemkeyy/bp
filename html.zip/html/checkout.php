<?php
require_once('config.php');

//session
session_start();

//count items in array
$cartItems = count($_SESSION['tedi']);
$cart = $_SESSION['tedi'];

//redirect if self navigating pages
if($cartItems < 1)
   {
   header("Location: cart.php");
   }

if(isset($_POST['submit'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $_SESSION['email'] = strip_tags($email);
    $name = trimstrip($_POST['name']);
		$_SESSION['name'] = mysqli_real_escape_string($conn, $name);

		if(empty($_SESSION['email']) || empty($_SESSION['name'])){
		    $message = "<span class='errMsg'>Form is incomplete!</span>";
		} else {
		header('Location: confirm.php');
		}
}

function trimstrip($inputStr){
	 $trim = trim($inputStr);
	 $outputStr = strip_tags($trim);
	 return $outputStr;
}

?>
<?php
include("template/top.php");
?>
<div id="viewCart">
  <span id="viewTitle">Shipping Information</span><br>
  <form method="post">
  EMAIL<br>
  <input type="email" class="text" name="email" value="<?php if(isset($_SESSION['email'])){ echo $_SESSION['email']; }?>"><br>
  NAME<br>
  <input type="text" class="text" name="name" value="<?php if(isset($_SESSION['name'])){ echo $_SESSION['name']; }?>"><br>
  <div id="checkCont"><input type="submit" class="button" value="SUBMIT" name="submit"></form></div>
  <a href="cart.php">Go Back</a><br>
  <?php if(isset($message)){ echo $message; } ?>
</div>
<br>
<?php
include("template/bottom.php");
?>

<?php
error_reporting(E_ALL);
require_once('config.php');
require_once('devfuturenow/rpc.php');

//session
session_start();

//count items in array
$cartItems = count($_SESSION['tedi']);
$cart = $_SESSION['tedi'];

if($cartItems < 1){
   header("Location: cart.php");
}


mysqli_set_charset($conn,"utf8");



$usdOwed = 0;
$coindesk = json_decode(file_get_contents("https://api.coindesk.com/v1/bpi/currentprice/usd.json"));
$_SESSION['exr'] = $coindesk->bpi->USD->rate_float;

	for($i=0; $i<$cartItems; $i++)
	{
	$queryLoopCart = "SELECT * FROM products WHERE id = '$cart[$i]'";
	$doLoopCart = mysqli_query($conn, $queryLoopCart) or die(mysqli_error($conn));
	$rowLoopCart = mysqli_fetch_assoc($doLoopCart);
	$loopPrice = $rowLoopCart['price'];
	$usdOwed += $loopPrice;
	}
	$btcOwed = $usdOwed / $_SESSION['exr'];

if(isset($_POST['confirm']))
{
    $paid = 0;
	$time = time();
	$complete = 0;
    $orderID = uniqid();
	$orderData = implode(" ",$_SESSION['tedi']);
	$orderCost = round($btcOwed, 6);
	$_SESSION['orderCost'] = $orderCost;
	$email = $_SESSION['email'];
	$name = $_SESSION['name'];


  $address = rpcCall("176.223.143.233","8332", "DPJidjoewjdejw", "FDSPFKQWPoedkpowejde0wjfd", "getnewaddress");

  $payTo = $address->result;
	$_SESSION['payTo'] = $payTo;

	//insert into DB
	$queryOrder = "INSERT INTO orders (orderid, time, name, email, cost, payto, items, paid, complete) VALUES ('$orderID', '$time', '$name', '$email', '$orderCost', '$payTo', '$orderData', '$paid', '$complete')";
	$doOrder = mysqli_query($conn, $queryOrder) or die(mysqli_error($conn));
	if(!$doOrder) {
			die('Error: '.mysqli_error($conn));
	} else {
			$host = $_SERVER['SERVER_NAME'];
			$emailTitle = "New Purchase";
			$emailTitle_Customer = "Order Confirmation";
			$bodyEmail = <<<EOD
        <h1>New Purchase</h1>
        Order: $orderID <br>
        Email: $email <br>
        Name: $name <br>
        Payment Address: $payTo <br>
		Payment Amount: $orderCost <br>
EOD;

        $headers = "From: noreply@".$host."\r\n";
        $headers .= "Content-type: text/html\r\n";
        $success = mail("$yourEmail", "$emailTitle", "$bodyEmail", "$headers");

        $custEmail = <<<EOD
        <h3>Please send payment to finalize your purchase</h3>
        Payment Address: $payTo <br>
        Payment Amount: $orderCost <br>
        Order: $orderID <br>
        Email: $email <br>
        Name: $name <br>
EOD;
        $customerCopy = mail($email, $emailTitle_Customer, $custEmail, $headers);
			header('Location: pay.php');
			}
}

?>

<?php
include("template/top.php");
?>
<div id="viewCart">
  <span id="viewTitle">Review & Confirm</span><br>
  Ship To:
  <div class="confirmShip">
  <?php
  echo htmlspecialchars($_SESSION['name'])."<br>";
  echo htmlspecialchars($_SESSION['email'])."<br>";
  ?>
  <a href="checkout.php">EDIT</a>
  </div><br><br>
  Order:
  <div class="confirmShip">
  <?php
 $usdOwed = 0;
	for($i=0; $i<$cartItems; $i++)
	{
	$queryLoopCart = "SELECT * FROM products WHERE id = '$cart[$i]'";
	$doLoopCart = mysqli_query($conn, $queryLoopCart);
	$rowLoopCart = mysqli_fetch_assoc($doLoopCart);
	$loopName = $rowLoopCart['name'];
	$loopPrice = $rowLoopCart['price'];
	$usdOwed += $loopPrice;
	$btcOwed = $usdOwed / $_SESSION['exr'];
	echo $loopName." $".$loopPrice."<br>";
	}
	echo "$".$usdOwed."<br>";
	echo "&#x0E3F;".number_format($btcOwed, 6)."<br>";
	?>
  <a href="cart.php">EDIT</a>
  </div><br>
  <div id="checkCont"><form method="post"><input type="submit" class="button" value="CONFIRM & PAY" name="confirm"></form></div>
  <br>
</div>
<br>
<?php
include("template/bottom.php");
?>

<?php
require_once("rpc.php");
class stdObject {
    public function __construct(array $arguments = array()) {
        if (!empty($arguments)) {
            foreach ($arguments as $property => $argument) {
                $this->{$property} = $argument;
            }
        }
    }

    public function __call($method, $arguments) {
        $arguments = array_merge(array("stdObject" => $this), $arguments); // Note: method argument 0 will always referred to the main class ($this).
        if (isset($this->{$method}) && is_callable($this->{$method})) {
            return call_user_func_array($this->{$method}, $arguments);
        } else {
            throw new Exception("Fatal error: Call to undefined method stdObject::{$method}()");
        }
    }
}



$fld = 'db/';
$files = scandir($fld);
$addresses = array();
$datausers = (object) array();
foreach($files as $file) {
  if (strlen($file) < 4) {
    continue;
  }
  $datauser = json_decode(file_get_contents($fld.$file));
  $datauser->file = $file;
  $datausers->{$datauser->address} = $datauser;
}

$txs = rpcCall("176.223.143.233","8332", "DPJidjoewjdejw", "FDSPFKQWPoedkpowejde0wjfd", "getbalance", []);
print_r($txs);
exit;
if ($txs && $txs->result && count($txs->result)) {
  foreach($txs->result as $tx) {
    $addr = $tx->address;
    if (isset($datausers->{$addr}) && $tx->confirmations > 1 && $tx->confirmations < 7) {
      echo "Found $addr $tx->amount BTC with $tx->confirmations confirmations.\n";
      if (!isset($datausers->{$addr}->txs))
        $datausers->{$addr}->txs = (object) array();
      $datausers->{$addr}->txs->{$tx->txids[0]} = [
        "value" => $tx->amount,
        "confirmations" => $tx->confirmations
      ];
      file_put_contents($fld.$datausers->{$addr}->file, json_encode($datausers->{$addr}));
    }
  }
}

?>

<?php
	try{
		if (!file_exists('anti_ddos/start.php'))
			throw new Exception ('anti_ddos/start.php does not exist');
		else
			require_once('anti_ddos/start.php'); 
	} 
	//CATCH the exception if something goes wrong.
	catch (Exception $ex) {
		// et's print a message saying there is an error
		echo '<div style="padding:10px;color:white;position:fixed;top:0;left:0;width:100%;background:black;text-align:center;">The <a href="https://github.com/sanix-darker/antiddos-system" target="_blank">"AntiDDOS System"</a> failed to load properly on this Web Site, please de-comment the \'catch Exception\' to see what happening!</div>';
		//Print out the exception message.
		//echo $ex->getMessage();
	}
	// cp -r AntiDDOS-system/ /var/www/html/
error_reporting(0);
require_once('config.php');

//session
session_start();
//create empty array for cart
if(!isset($_SESSION['tedi'])){
$_SESSION['tedi'] = array();
}
//get current exchange rate
if(!isset($_SESSION['exr'])){
	$url = "https://www.bitstamp.net/api/ticker/";
	$fgc = file_get_contents($url);
	$json = json_decode($fgc, TRUE);
	$price = (int)$json["last"];

	$_SESSION['exr'] = $price;

}

//count items in array
$cartItems = count($_SESSION['tedi']);
$cart = $_SESSION['tedi'];

//add to cart buttons
$queryProducts2 ="SELECT * FROM products WHERE in_stock > 0 ORDER BY id ASC";
$resultH2=mysqli_query($conn, $queryProducts2) or die ("database connection error check server log");
	//loop through different product ids
	while($outputsH2=mysqli_fetch_assoc($resultH2)){
	if(isset($_POST[$outputsH2['id']])){
		   array_push($_SESSION['tedi'], $outputsH2['id']);
		   $cartItems = count($_SESSION['tedi']);
		   $cart = $_SESSION['tedi'];
	   }
	}


include("template/top.php");

$productsHtml = "";
$queryProducts ="SELECT * FROM products ORDER BY id ASC";
$resultH=mysqli_query($conn, $queryProducts) or die ("error fetching products table");
while($outputsH=mysqli_fetch_assoc($resultH)){
  $productsHtml .= '<div class="col-md-6 col-lg-4 product text-white">
  <input type="hidden" class="metadata" value="'.base64_encode(json_encode($prod)).'" />
  <h2>'.$outputsH['name'].'</h2>
	<div class="status">STATUS : <span class="status-span">'.($outputsH['in_stock'] && $outputsH['in_stock'] > 0 ? 'In Stock' : 'Out of Stock').'</span></div>
  <div class="price">PRICE : <span class="price-span">$'.$outputsH['price'].'</span></div>';
	if ($outputsH['image'] && $outputsH['image'] != "") {
		$productsHtml .= '<div class="picture-header"></div><div class="img-container">
	    <img src="'.$outputsH['image'].'" alt="">
	  </div>';
	}
	$productsHtml .= '<div class="wrapper">
    <div class="text">'.substr($outputsH['description'], 0, 200).' ...</div>
		<div class="text"><form method="post"><input type="submit" class="btn btn-success btn-block btn-buy" value="Purchase" name="'.$outputsH['id'].'"></form></div>
  </div>
</div>';

}
?>
<?=$productsHtml?>

<?php
echo "<div class='shopCont'><hr></div>";
include("template/bottom.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title><?php echo $storeName; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!--<link rel="stylesheet" type="text/css" href="style.css">-->

  <style>
    .img-container {
      margin-bottom: 10px;
      overflow: hidden;
    }

    .img-container img {
      width: 100%;
    }

    .product {
      padding-top: 20px;
      padding-bottom: 20px;
    }

    .status,
    .price {
      font-weight: 700;
    }

    .status,
    .text,
    .price {
      padding-bottom: 5px;
    }

    .status-span,
    .price-span {
      font-weight: normal;
    }

    .text {
      padding-bottom: 12px;
    }

    .picture-header {
      padding-bottom: 5px;
    }

    @media (max-width: 768px) {
      .img-container {
        height: auto;
      }

      .img-container img {
        height: 100%;
      }
    }
    #paymentInfo {
      width:300px;
      left:50%;
      top:50%;
      margin-left:-150px;
      margin-top:-150px;
      position:absolute;
      z-index:999;
      padding:15px;
      background: #fff;
      border:1px dashed #111;
    }
  </style>
  <script>
  function loopCheckTX(prod) {
    setTimeout(async function() {
      const check = await $.get(window.location.pathname+"?checktx="+prod.valuebuy);
      console.log("check",check);
      if (check.indexOf("yes") !== -1) {
        $("#paymentInfo .pending").hide();
        $("#paymentInfo .success").show();
        $("#paymentInfo .success .product").html('<h2>'+prod.title+'</h2><div class="status">STATUS : <span class="status-span">'+prod.status+'</span></div><div class="price">PRICE : <span class="price-span">'+prod.price+'</span></div><div class="picture-header">'+prod.imgtxt+'</div><div class="img-container">  <img src="'+prod.img+'" alt=""></div><div class="wrapper">  <div class="text">'+prod.desc+'</div>  <button class="btn btn-success btn-block btn-buy">BUY</button></div>');
      } else {
        loopCheckTX(prod);
      }
    }, 3000);
  }
  const decodeBase64 = function(s) {
    if (!s)
      return "";
    var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
    var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for(i=0;i<64;i++){e[A.charAt(i)]=i;}
    for(x=0;x<L;x++){
        c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
        while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
    }
    return r;
  };
  const startTimer = function() {
     $('#paymentInfo span.time').text(--sec);
     if (sec == 0) {
        $('#paymentInfo').fadeOut('fast');
        clearInterval(timer);
     }
  }

  $(document).ready(async function() {
      let exchangeRate = await $.getJSON( "https://api.coindesk.com/v1/bpi/currentprice/usd.json");
      exchangeRate = parseFloat(exchangeRate.bpi.USD.rate_float);
      $(document).click(function(e) {
          var container = $("#paymentInfo");
          if (!container.is(e.target) && container.has(e.target).length === 0 && !$(e.target).hasClass("btn-buy")) {
          console.log("e.target",e.target);
              container.hide();
          }
      });

      $( ".btn-buy" ).click(async function() {
        const el = $(this).parent().parent().find('.metadata').attr("value");
        let meta = JSON.parse(decodeBase64(el));
        if (meta.id >= 0) {
          $("#paymentInfo").show();
          const addr = await $.get(window.location.pathname+"?address");
          $("#paymentInfo .address").val(addr);
          $("#paymentInfo .value").val((meta.priceval / exchangeRate).toFixed(8));
          meta.valuebuy = (meta.priceval / exchangeRate).toFixed(8);
          timer = setInterval(startTimer, 1000);
          loopCheckTX(meta);
        }
      });
  });

  var sec = 60*60*2;
  var timer;
  </script>
  <style>
    .img-container {
      margin-bottom: 10px;
      overflow: hidden;
    }

    .img-container img {
      width: 100%;
    }

    .product {
      padding-top: 20px;
      padding-bottom: 20px;
    }

    .status,
    .price {
      font-weight: 700;
    }

    .status,
    .text,
    .price {
      padding-bottom: 5px;
    }

    .status-span,
    .price-span {
      font-weight: normal;
    }

    .text {
      padding-bottom: 12px;
    }

    .picture-header {
      padding-bottom: 5px;
    }

    @media (max-width: 768px) {
      .img-container {
        height: auto;
      }

      .img-container img {
        height: 100%;
      }
    }
    #paymentInfo {
      width:300px;
      left:50%;
      top:50%;
      margin-left:-150px;
      margin-top:-150px;
      position:absolute;
      z-index:999;
      padding:15px;
      background: #fff;
      border:1px dashed #111;
    }
  </style>
</head>

<body>
  <div id="paymentInfo" style="display:none">
    <div class="pending">
      Please procced with the payment to the following details:<br><br>
      Value: <input type="text" class="value" value=""/><br>
      Address: <input type="text" class="address" value=""/><br><br>
      <div style="text-align:center">Confirming...</div>
      <div style="text-align:center">Time left: <span class="time">0</span>secs</div>
    </div>
    <div class="success" style="display:none">
      Congratulations, you've bought the following product:<br>
      <div class="product">

      </div>
    </div>
  </div>
  <div class="jumbotron text-center" style="margin-bottom:0">
    <h1>HEADER</h1>

    <?php if ($_SESSION['email']) { ?>
      <form class="login-form" name="login_form" id="login_form" method="post" action="logout.php">
        Hello, <?php echo $_SESSION['email']; ?>!
        <button>log-Out</button>
      </form>
    <?php } else { ?>
      Hello, Guest!
    <?php } ?>
  </div>

  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <a class="navbar-brand" href="#">INFO</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        </li>
      </ul>
    </div>
  </nav>

  <div class="container" style="margin-top:30px">
    <div class="row">
